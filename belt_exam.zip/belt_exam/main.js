function showMessage() {
    alert("Your Cart is empty!");
}

document.querySelector('.link').addEventListener('click', () => document.querySelector('#bar').style = "display:none")